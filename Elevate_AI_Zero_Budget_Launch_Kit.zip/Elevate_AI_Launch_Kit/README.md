# Elevate AI website

## Publish with GitHub Pages
1. Create a **public** GitHub repository named `elevate-ai-site`.
2. Upload `index.html` directly to the repository root and commit it.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for GitHub Pages to publish and open the URL it displays.

## Connect your Spaceship domain
After GitHub Pages is active, enter `elevateaigrowth.com` in Settings → Pages → Custom domain. Follow the DNS records shown by GitHub and add them in Spaceship's DNS settings. Do not change nameservers. DNS and HTTPS certificate setup can take time.

## Important before publishing
The contact form currently uses `hello@elevateaigrowth.com` and opens the visitor's email app; it does not collect leads automatically. Set up and test that mailbox, or replace the address in `index.html` with an inbox you can access. Review all claims, pricing, and service scope before publishing.
