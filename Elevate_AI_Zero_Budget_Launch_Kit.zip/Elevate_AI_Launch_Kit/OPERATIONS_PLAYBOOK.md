# Elevate AI — lean launch playbook

## Initial service
Help small businesses organize new lead inquiries, prepare approved responses, set follow-up reminders, and route unusual or sensitive requests to a person.

## Suggested packages
- Starter: $297/month — one workflow and basic follow-up reminders.
- Growth: $497/month — multiple workflows and monthly reporting.
- Scale: $997/month — expanded workflow support and optimization.

These are proposed prices, not guaranteed sales or income. Confirm scope and software costs with each client.

## Delivery workflow
1. Interview the owner and map how inquiries arrive.
2. Agree on response wording, business hours, escalation rules, and data access.
3. Build a simple workflow using tools the client approves.
4. Test with sample leads before going live.
5. Monitor exceptions and review results monthly.

## Automation guardrails
Keep a human responsible for approvals, unusual situations, complaints, refunds, and high-impact decisions. Get permission before accessing customer data. Use only the minimum data needed, secure accounts, and never promise guaranteed bookings or revenue.

## 30-day start
Week 1: choose one niche and interview five business owners.
Week 2: build a demonstration workflow with dummy data.
Week 3: contact a small, relevant list with personalized, compliant messages.
Week 4: run a paid pilot only after agreeing in writing on deliverables, access, and support.

## Admin checklist
Choose a business email and test it. Check Ohio trade-name/sole-proprietor requirements and tax obligations with official sources or a qualified professional. Consider a written service agreement and appropriate insurance before handling client data.
