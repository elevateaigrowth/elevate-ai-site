# Elevate AI reusable prompts

## Map a lead process
You are an operations assistant. Given the business process below, map how a new inquiry arrives, who owns it, the next action, the response-time goal, and when a human must intervene. Do not invent policies. Ask questions where details are missing.

## Draft an approved response
Draft a concise, friendly response to this customer inquiry using only the business facts and policies supplied below. If the request involves pricing not provided, complaints, refunds, emergencies, legal/medical advice, or uncertainty, flag it for human review instead of guessing.

## Monthly workflow review
Summarize the supplied workflow metrics. Separate measured facts from interpretations. Identify bottlenecks and suggest low-risk tests. Do not claim causation or guaranteed revenue impact.
