# Elevate AI outreach templates

## Personalized first message
Subject: A simple way to improve lead follow-up at [Business]

Hi [Name],

I noticed [specific, genuine detail about the business]. I help small businesses organize incoming inquiries and follow-up so fewer potential customers get overlooked.

Would a brief conversation about your current lead process be useful? If not, no worries.

— Elevate AI

## Follow-up
Hi [Name], just checking whether improving inquiry response and follow-up is a priority right now. If it is, I can share a simple example workflow. If not, I won't keep following up.

## Good practice
Contact only appropriate business prospects, personalize messages, identify yourself accurately, honor opt-outs, and comply with applicable email, texting, telemarketing, and platform rules. Do not scrape personal data or send bulk unsolicited messages.
